#include <Arduino_ConnectionHandler.h>

/* A complete list of supported boards with WiFi is available here:
 * https://github.com/arduino-libraries/ArduinoIoTCloud/#what
 */
#if defined(BOARD_HAS_WIFI)
  #define SECRET_WIFI_SSID "YOUR_WIFI_NETWORK_NAME"
  #define SECRET_WIFI_PASS "YOUR_WIFI_PASSWORD"
#endif

/* ESP8266 ESP32 */
#if !defined(BOARD_HAS_SECURE_ELEMENT)
  #define SECRET_DEVICE_KEY "my-device-password"
#endif

/* MKR GSM 1400 */ /* MKR NB 1500 */ /* Portenta CAT.M1/NB IoT GNSS Shield */
/* Portenta H7 and C33 + Portenta Mid Carrier + 4G Module */
#if defined(BOARD_HAS_GSM) || defined(BOARD_HAS_NB) || \
    defined(BOARD_HAS_CATM1_NBIOT) || defined(BOARD_HAS_CELLULAR)
  #define SECRET_PIN ""
  #define SECRET_APN ""
  #define SECRET_LOGIN ""
  #define SECRET_PASS ""
#endif

/* Portenta H7 + Ethernet shield */
#if defined(BOARD_HAS_ETHERNET)
  #define SECRET_OPTIONAL_IP ""
  #define SECRET_OPTIONAL_DNS ""
  #define SECRET_OPTIONAL_GATEWAY ""
  #define SECRET_OPTIONAL_NETMASK ""
#endif
